Given(/^I select "(Sign in|create and acount)"$/) do |arg1|
pending # Write code here that turns the phrase above into concrete actions
end

Then(/^I should see the "(account main|create a new account)" page$/) do |arg1|
  pending # Write code here that turns the phrase above into concrete actions
end